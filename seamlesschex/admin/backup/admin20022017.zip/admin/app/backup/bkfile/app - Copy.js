var app = angular.module('employeeRecords', [])
        .constant('API_URL', 'http://localhost:8080/laravel/seamlesschex/api/public/api/v1/');
