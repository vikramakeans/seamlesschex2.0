/*(function() {

	'use strict';

	angular
		.module('authApp')
		.controller('PlanController', PlanController);
		function PlanController($scope) {
			$scope.value= '24.99';
			//$scope.planAmount={};
			$scope.setAmount = function(value) {
			   console.log(value);
			   //$scope.planAmount.value = value;
			   //console.log($scope.planAmount.value);
			}
		}
})();*/